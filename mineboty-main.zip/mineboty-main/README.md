mineboty
========

mineboty is an npm package to make minecraft bot in a minute 
also you can connect to discord to do direct chat from discord to minecraft server
it will help you to make best in pvp will also guard the place
MADE BY-TEAMIC
=====================

# about Team IC Mineboty 

- Mineboty is a Npm package to keep your aternos server 24/7 and also you can pratice pvp with mineboty & more


# how to use mineboty

- best and easy way to use mineboty is using replit 
- toturial videos [for replit click here](https://www.youtube.com/watch?v=WZwroM4NdBU&t=0s)   |   [for GLITCH click here](https://www.youtube.com/watch?v=6sPwCrHFYCY) | [for heroku click here](https://www.youtube.com/watch?v=YMVFHtkmSzg)
- for more support [join discord here](https://discord.gg/8bM62csKYd)
- Team IC Discord - [Join Now](https://dsc.gg/team-ic)
- Team IC Website - [Website](https://teamic.me)

# update status v1.0.8

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
- added costem cmds 
- - bugs fix
- :)    
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -                             

