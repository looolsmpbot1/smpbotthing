const {mineboty} = require("mineboty")
mineboty();

console.log(`
███████╗
██╔════╝
█████╗░░
██╔══╝░░
███████╗
╚══════╝`);



console.log(`
████████╗███████╗░█████╗░███╗░░░███╗░░░░░░██╗░█████╗░
╚══██╔══╝██╔════╝██╔══██╗████╗░████║░░░░░░██║██╔══██╗
░░░██║░░░█████╗░░███████║██╔████╔██║█████╗██║██║░░╚═╝
░░░██║░░░██╔══╝░░██╔══██║██║╚██╔╝██║╚════╝██║██║░░██╗
░░░██║░░░███████╗██║░░██║██║░╚═╝░██║░░░░░░██║╚█████╔╝
░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝░░░░░░╚═╝░╚════╝░ \n \n \n \nmineboty developers \n *Kartik OP*#4791 \n youtube = "https://www.youtube.com/c/CodingIndia" \n \n \n ||**AshishOp.tar.gz**||#5693 \n youtube = "https://youtube.com/c/gtasish" \n \n \n \n \n \n website = "https://teamic.me" \n \n  `);







